# Zarya add-on contracts

The SDK supplies framework-independent extension contracts shared by CMS Zarya
and independently built add-ons. Read its current version/toolchain from this
package's package.json; SDK and CMS versions are independent.

- addons: definition/configuration metadata, site connection state, operation access
  classes, captured permits and the typed browser administration host.
- business-error, validation, cursor-page, snapshot-entity: portable errors/value
  checks, paged results and defensive business snapshots.
- cms: portable ICmsApi data contracts without core/domain/framework imports.
- cms-extensions: ICmsAddonApiHost, ICmsAddonExtension, Query/Command kinds and
  JSON method contracts. Runtime methods are code-owned; the host scopes site/actor
  and rechecks connection availability, including query-only restrictions.

The SDK contains no NestJS providers, Mongoose types, repositories, service
locators or permission grants. The host authorizes actors/sites and enforces
captured permits at write commit; add-ons own business rules and persistence.

Build with `npm run build:contracts`; package with
`npm pack --workspace @zarya/addon-contracts`. Independent development uses the
fixed-version SDK artifact and committed lockfile integrity, never sibling source.
Installed prebuilt runtime consumers do not need a duplicate npm add-on dependency.

Admin extensions use the host's time zone, route/query history, private configuration,
dirty/busy state and scroll-shadow action. Reuse CMS theme classes, not host source
or copied styles. adminMenuLabels contains presentation overrides, not authority.

See the [developer guide](../../docs/guide/en/README.md) and
[add-on contracts](../../docs/arch/site-addons-contracts.md).
